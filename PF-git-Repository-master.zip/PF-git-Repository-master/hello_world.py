print('Hello world!')
print("Hello 2")
print("Hello 3")
print("Hello 4")